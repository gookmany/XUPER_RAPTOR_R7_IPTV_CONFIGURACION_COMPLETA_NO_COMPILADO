# Corrección de importación M3U grandes

## Cambios realizados
- El importador de archivo local ya no llama `readText()` para crear una copia completa del M3U en memoria.
- El analizador acepta un `Reader` y recorre el archivo línea por línea.
- El catálogo de elementos se guarda en una base de datos SQLite con transacción, en lugar de serializar toda la lista como un único JSON en `EncryptedSharedPreferences`.
- Las escrituras del catálogo durante la importación se ejecutan en `Dispatchers.IO`.
- Se conserva `EncryptedSharedPreferences` para los datos pequeños de las fuentes y credenciales.
- Se añadió migración de mejor esfuerzo para catálogos antiguos guardados como JSON cuando todavía son legibles.

## Límites de validación
Este paquete contiene cambios de código fuente. En el entorno de preparación no está disponible el comando `gradle` ni un SDK Android configurado, así que no se afirma que el proyecto haya compilado ni que se haya probado en un dispositivo. Debe compilarse en Android Studio o mediante el workflow de GitHub Actions y probarse con una lista grande real.

## Nota
El analizador ya no mantiene una segunda copia de todo el texto de entrada, pero todavía acumula las entradas parseadas en una lista antes de insertarlas en SQLite. Para listas extraordinariamente grandes, una mejora posterior sería analizar e insertar en lotes de forma incremental, con progreso visible.

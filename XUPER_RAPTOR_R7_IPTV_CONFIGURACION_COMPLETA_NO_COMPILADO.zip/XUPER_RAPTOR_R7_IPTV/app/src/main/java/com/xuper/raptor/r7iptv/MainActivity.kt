package com.xuper.raptor.r7iptv

import android.os.Bundle
import android.app.Activity
import android.content.pm.ActivityInfo
import android.view.View
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material3.CircularProgressIndicator
import kotlinx.coroutines.launch
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.runtime.DisposableEffect

private val Backdrop = Color(0xFF090B10)
private val Panel = Color(0xFF151A23)
private val Accent = Color(0xFFE53935)
private val TextMain = Color(0xFFF5F7FA)
private val TextMuted = Color(0xFF9BA6B5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RaptorApp() }
    }
}

private enum class Screen { WELCOME, HOME, SETTINGS, PLAYER_SETTINGS, INTERFACE_SETTINGS, SOURCES, XTREAM, M3U, CATALOG, SERIES_DETAIL, PLAYER }

@Composable
private fun RaptorApp() {
    val context = LocalContext.current
    val repository = remember { IptvSourceRepository(context) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var screen by rememberSaveable { mutableStateOf(Screen.WELCOME) }
    var notice by rememberSaveable { mutableStateOf("") }
    var sources by remember { mutableStateOf(repository.getAll()) }
    var busy by rememberSaveable { mutableStateOf(false) }
    var selectedSourceId by rememberSaveable { mutableStateOf("") }
    var catalogEntries by remember { mutableStateOf(emptyList<M3uEntry>()) }
    var selectedEntry by remember { mutableStateOf<M3uEntry?>(null) }
    var seriesEpisodes by remember { mutableStateOf(emptyList<M3uEntry>()) }
    var selectedSeriesTitle by rememberSaveable { mutableStateOf("Serie") }
    fun refreshSources() { sources = repository.getAll() }
    val pickM3uFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                try {
                    notice = "Leyendo y analizando la lista M3U…"
                    val label = uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() } ?: "Lista M3U local"
                    val entries = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        val input = context.contentResolver.openInputStream(uri)
                            ?: throw IllegalStateException("No se pudo abrir el archivo seleccionado")
                        input.bufferedReader(Charsets.UTF_8).use { reader -> M3uParser.parse(reader) }
                    }
                    if (entries.isEmpty()) throw IllegalStateException("El archivo no contiene entradas M3U reconocibles")
                    val saved = IptvSource(name = label, type = SourceType.M3U_FILE, url = uri.toString(), itemCount = entries.size)
                    // Catalog database writes run off the UI thread and commit as one transaction.
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        repository.saveEntries(saved.id, entries)
                    }
                    repository.save(saved)
                    refreshSources()
                    notice = "Archivo importado correctamente: ${entries.size} elementos."
                } catch (e: Exception) {
                    notice = "No se pudo importar el archivo: ${e.message ?: "archivo no válido"}"
                } finally { busy = false }
            }
        }
    }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = Backdrop, contentColor = TextMain) {
            when (screen) {
                Screen.WELCOME -> WelcomeScreen(onEnter = { screen = Screen.HOME }, onSettings = { screen = Screen.SETTINGS })
                Screen.HOME -> HomeScreen(
                    sourceCount = sources.size, notice = notice,
                    onSettings = { screen = Screen.SETTINGS },
                    onCategory = { category ->
                        val source = sources.firstOrNull()
                        if (source == null) {
                            notice = "$category: añade una fuente IPTV desde Configuración."
                        } else {
                            selectedSourceId = source.id
                            catalogEntries = repository.getEntries(source.id)
                            screen = Screen.CATALOG
                            if (source.type == SourceType.XTREAM && category in listOf("LIVE", "MOVIES", "SERIES")) {
                                scope.launch {
                                    busy = true
                                    notice = "Cargando $category desde ${source.name}…"
                                    try {
                                        val result = when (category) {
                                            "MOVIES" -> XtreamApi.testAndLoadMovies(source)
                                            "SERIES" -> XtreamApi.testAndLoadSeries(source)
                                            else -> XtreamApi.testAndLoadLive(source)
                                        }
                                        repository.saveEntries(source.id, result.second)
                                        repository.save(source.copy(itemCount = result.second.size))
                                        catalogEntries = result.second
                                        refreshSources()
                                        notice = "$category: ${result.second.size} elementos cargados. Estado de cuenta: ${result.first.status}."
                                    } catch (e: Exception) {
                                        notice = "No se pudo cargar $category: ${e.message ?: "error de conexión"}"
                                    } finally { busy = false }
                                }
                            } else {
                                val all = repository.getEntries(source.id)
                                catalogEntries = when (category) {
                                    "LIVE" -> all.filter { it.mediaType.equals("LIVE", true) }
                                    "MOVIES" -> all.filter { it.mediaType.equals("MOVIE", true) }
                                    "SERIES" -> all.filter { it.mediaType.equals("SERIES", true) }
                                    "KIDS" -> all.filter { (it.group + " " + it.name).contains(Regex("\\b(kids?|children|infantil|niños|ninos|dibujos|cartoon)\\b", RegexOption.IGNORE_CASE)) }
                                    "ANIME" -> all.filter { (it.group + " " + it.name).contains(Regex("anime", RegexOption.IGNORE_CASE)) }
                                    "FEATURED" -> all.take(100)
                                    else -> all
                                }
                                notice = if (catalogEntries.isEmpty()) "$category: no hay elementos guardados en esta fuente. Entra en el catálogo y carga la categoría compatible." else "$category: ${catalogEntries.size} elementos disponibles."
                            }
                        }
                    }
                )
                Screen.SETTINGS -> SettingsScreen(
                    onBack = { screen = Screen.HOME }, onSources = { screen = Screen.SOURCES },
                    onPlayer = { screen = Screen.PLAYER_SETTINGS }, onInterface = { screen = Screen.INTERFACE_SETTINGS }
                )
                Screen.PLAYER_SETTINGS -> PlayerPreferencesScreen(onBack = { screen = Screen.SETTINGS })
                Screen.INTERFACE_SETTINGS -> InterfacePreferencesScreen(onBack = { screen = Screen.SETTINGS })
                Screen.SOURCES -> SourcesScreen(
                    onBack = { screen = Screen.SETTINGS }, onXtream = { screen = Screen.XTREAM }, onM3u = { screen = Screen.M3U },
                    sources = sources,
                    onPickM3uFile = { pickM3uFile.launch(arrayOf("application/vnd.apple.mpegurl", "audio/x-mpegurl", "text/plain", "application/octet-stream")) },
                    onDelete = { id -> repository.delete(id); refreshSources(); notice = "Fuente eliminada." },
                    onOpenCatalog = { source ->
                        selectedSourceId = source.id
                        catalogEntries = repository.getEntries(source.id)
                        screen = Screen.CATALOG
                        if (source.type == SourceType.XTREAM) {
                            scope.launch {
                                busy = true
                                notice = "Conectando con Xtream Codes y cargando canales…"
                                try {
                                    val (account, entries) = XtreamApi.testAndLoadLive(source)
                                    repository.saveEntries(source.id, entries)
                                    repository.save(source.copy(itemCount = entries.size))
                                    catalogEntries = entries
                                    refreshSources()
                                    notice = "Xtream verificado: ${entries.size} canales. Estado: ${account.status}."
                                } catch (e: Exception) {
                                    notice = "Error Xtream: ${e.message ?: "no se pudo conectar"}"
                                } finally { busy = false }
                            }
                        }
                    }
                )
                Screen.CATALOG -> CatalogScreen(
                    source = sources.firstOrNull { it.id == selectedSourceId },
                    entries = catalogEntries,
                    onPlay = { entry ->
                        val source = sources.firstOrNull { it.id == selectedSourceId }
                        // An M3U label is only a best-effort classification; it does not
                        // provide the Xtream series_id needed to query seasons/episodes.
                        if (entry.mediaType == "SERIES" && source != null && source.type == SourceType.XTREAM) {
                            scope.launch {
                                busy = true
                                notice = "Cargando temporadas y episodios…"
                                try {
                                    val (title, episodes) = XtreamApi.loadSeriesEpisodes(source, entry.tvgId)
                                    selectedSeriesTitle = title
                                    seriesEpisodes = episodes
                                    screen = Screen.SERIES_DETAIL
                                    notice = if (episodes.isEmpty()) "La serie no tiene episodios disponibles." else "$title: ${episodes.size} episodios cargados."
                                } catch (e: Exception) {
                                    notice = "No se pudieron cargar los episodios: ${e.message ?: "error de conexión"}"
                                } finally { busy = false }
                            }
                        } else {
                            selectedEntry = entry
                            screen = Screen.PLAYER
                            if (entry.mediaType == "SERIES" && source?.type != SourceType.XTREAM) {
                                notice = "Entrada M3U clasificada como serie: se abrirá el enlace directo disponible."
                            }
                        }
                    },
                    onBack = { screen = Screen.SOURCES },
                    onLoadMovies = { source ->
                        scope.launch {
                            busy = true
                            notice = "Cargando catálogo de películas desde Xtream Codes…"
                            try {
                                val (account, entries) = XtreamApi.testAndLoadMovies(source)
                                repository.saveEntries(source.id, entries)
                                repository.save(source.copy(itemCount = entries.size))
                                catalogEntries = entries
                                refreshSources()
                                notice = "Catálogo de películas cargado: ${entries.size} elementos. Estado: ${account.status}."
                            } catch (e: Exception) {
                                notice = "No se pudieron cargar películas: ${e.message ?: "error de conexión"}"
                            } finally { busy = false }
                        }
                    },
                    onLoadSeries = { source ->
                        scope.launch {
                            busy = true
                            notice = "Cargando catálogo de series desde Xtream Codes…"
                            try {
                                val (account, entries) = XtreamApi.testAndLoadSeries(source)
                                repository.saveEntries(source.id, entries)
                                repository.save(source.copy(itemCount = entries.size))
                                catalogEntries = entries
                                refreshSources()
                                notice = "Catálogo de series cargado: ${entries.size} elementos. Estado: ${account.status}."
                            } catch (e: Exception) {
                                notice = "No se pudieron cargar series: ${e.message ?: "error de conexión"}"
                            } finally { busy = false }
                        }
                    },
                    onRefresh = { source ->
                        scope.launch {
                            busy = true
                            try {
                                val entries = when (source.type) {
                                    SourceType.M3U_URL -> M3uDownloader.downloadAndParse(source.url)
                                    SourceType.XTREAM -> XtreamApi.testAndLoadLive(source).second
                                    SourceType.M3U_FILE -> throw IllegalStateException("La importación de archivos locales aún no está disponible")
                                }
                                repository.saveEntries(source.id, entries)
                                repository.save(source.copy(itemCount = entries.size))
                                catalogEntries = entries
                                refreshSources()
                                notice = "Catálogo actualizado: ${entries.size} elementos."
                            } catch (e: Exception) {
                                notice = "No se pudo actualizar: ${e.message ?: "error de red"}"
                            } finally { busy = false }
                        }
                    }, busy = busy
                )
                Screen.SERIES_DETAIL -> SeriesDetailScreen(
                    title = selectedSeriesTitle,
                    episodes = seriesEpisodes,
                    busy = busy,
                    onPlay = { entry -> selectedEntry = entry; screen = Screen.PLAYER },
                    onBack = { screen = Screen.CATALOG }
                )
                Screen.PLAYER -> PlayerScreen(
                    entry = selectedEntry,
                    onBack = { screen = Screen.CATALOG }
                )
                Screen.XTREAM -> XtreamScreen(
                    onBack = { screen = Screen.SOURCES },
                    onSave = { label, server, username, password ->
                        val cleanServer = server.trim().trimEnd('/')
                        repository.save(IptvSource(name = label, type = SourceType.XTREAM, server = cleanServer, username = username.trim(), password = password))
                        refreshSources(); notice = "Fuente '$label' guardada de forma cifrada. Aún no se ha probado la conexión al servidor."; screen = Screen.SOURCES
                    }
                )
                Screen.M3U -> M3uScreen(
                    busy = busy, onBack = { screen = Screen.SOURCES },
                    onSave = { label, address ->
                        scope.launch {
                            busy = true
                            notice = "Descargando y analizando la lista M3U…"
                            try {
                                val entries = M3uDownloader.downloadAndParse(address.trim())
                                val saved = IptvSource(name = label.trim(), type = SourceType.M3U_URL, url = address.trim(), itemCount = entries.size)
                                repository.save(saved)
                                repository.saveEntries(saved.id, entries)
                                refreshSources()
                                notice = "Lista '$label' importada: ${entries.size} elementos detectados. La reproducción todavía no está conectada."
                                screen = Screen.SOURCES
                            } catch (e: Exception) {
                                notice = "No se pudo importar la lista: ${e.message ?: "error de red o formato"}"
                            } finally { busy = false }
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun BrandHeader() {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Box(Modifier.background(Accent, RoundedCornerShape(10.dp)).padding(horizontal = 12.dp, vertical = 8.dp)) {
            Text("R7", fontWeight = FontWeight.Black, fontSize = 20.sp, color = Color.White)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("XUPER RAPTOR", fontWeight = FontWeight.Black, fontSize = 19.sp, letterSpacing = 1.2.sp)
            Text("R7 IPTV", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Accent, letterSpacing = 3.sp)
        }
    }
}

@Composable
private fun WelcomeScreen(onEnter: () -> Unit, onSettings: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp, vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        BrandHeader()
        Spacer(Modifier.height(48.dp))
        Text("TU ENTRETENIMIENTO,\nEN UN SOLO LUGAR", fontSize = 26.sp, lineHeight = 32.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text("Reproductor IPTV para tus fuentes autorizadas", color = TextMuted, textAlign = TextAlign.Center)
        Spacer(Modifier.height(32.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("SISTEMA PREPARADO", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(8.dp))
                Text("Puedes entrar sin configurar una fuente.", color = TextMuted, textAlign = TextAlign.Center)
            }
        }
        Spacer(Modifier.height(26.dp))
        RaptorButton("ENTRAR", onEnter, Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        RaptorOutlineButton("CONFIGURACIÓN", onSettings, Modifier.fillMaxWidth())
        Spacer(Modifier.height(18.dp))
        Text("VERSIÓN 1.0.0 · IPTV PLAYER", color = TextMuted, fontSize = 10.sp, letterSpacing = 1.sp)
    }
}

@Composable
private fun HomeScreen(sourceCount: Int, notice: String, onSettings: () -> Unit, onCategory: (String) -> Unit) {
    val categories = listOf("LIVE", "FEATURED", "MOVIES", "SERIES", "KIDS", "ANIME", "EXPLORAR")
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            BrandHeader()
            Spacer(Modifier.weight(1f))
            RaptorOutlineButton("⚙", onSettings)
        }
        Spacer(Modifier.height(24.dp))
        Text("INICIO", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextMuted, letterSpacing = 2.sp)
        Spacer(Modifier.height(12.dp))
        if (sourceCount == 0) {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("Aún no hay fuentes IPTV", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("Abre Configuración → Fuentes IPTV para añadir Xtream Codes o una lista M3U.", color = TextMuted)
                    Spacer(Modifier.height(12.dp))
                    RaptorButton("CONFIGURAR FUENTES", onSettings)
                }
            }
            Spacer(Modifier.height(14.dp))
        } else {
            Text("Fuentes añadidas: $sourceCount · Fuentes configuradas y listas para consultar.", color = TextMuted)
            Spacer(Modifier.height(12.dp))
        }
        if (notice.isNotBlank()) {
            Text(notice, color = Accent, fontSize = 12.sp, modifier = Modifier.padding(bottom = 10.dp))
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            categories.forEach { category ->
                FocusCard(title = category, subtitle = if (category == "LIVE") "Televisión en directo" else "Explorar contenido", onClick = { onCategory(category) })
            }
        }
    }
}

@Composable
private fun SettingsScreen(onBack: () -> Unit, onSources: () -> Unit, onPlayer: () -> Unit, onInterface: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
        BrandHeader(); Spacer(Modifier.height(28.dp))
        Text("CONFIGURACIÓN", fontSize = 23.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(16.dp))
        FocusCard("Fuentes IPTV", "Xtream Codes · M3U · M3U8", onSources)
        Spacer(Modifier.height(10.dp))
        FocusCard("Reproductor", "Inicio automático, ajuste de imagen y orientación", onPlayer)
        Spacer(Modifier.height(10.dp))
        FocusCard("Interfaz", "Tamaño de texto, animaciones y controles", onInterface)
        Spacer(Modifier.height(10.dp))
        FocusCard("Acerca de", "XUPER RAPTOR R7 IPTV · 0.9.0", { })
        Spacer(Modifier.height(24.dp)); RaptorOutlineButton("VOLVER", onBack)
    }
}

private fun settingsPrefs(context: android.content.Context) = context.getSharedPreferences("raptor_user_preferences", android.content.Context.MODE_PRIVATE)

@Composable
private fun PlayerPreferencesScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { settingsPrefs(context) }
    var autoPlay by rememberSaveable { mutableStateOf(prefs.getBoolean("player_autoplay", true)) }
    var keepLandscape by rememberSaveable { mutableStateOf(prefs.getBoolean("player_landscape", false)) }
    var fitMode by rememberSaveable { mutableStateOf(prefs.getString("player_fit", "FIT") ?: "FIT") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
        BrandHeader(); Spacer(Modifier.height(24.dp))
        Text("REPRODUCTOR", fontSize = 23.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(8.dp)); Text("Estas preferencias se guardan en este dispositivo.", color = TextMuted)
        Spacer(Modifier.height(18.dp))
        PreferenceRow("Reproducir automáticamente", "Iniciar el contenido al abrir el reproductor", autoPlay) {
            autoPlay = it; prefs.edit().putBoolean("player_autoplay", it).apply()
        }
        PreferenceRow("Forzar orientación horizontal", "Usar pantalla apaisada al reproducir", keepLandscape) {
            keepLandscape = it; prefs.edit().putBoolean("player_landscape", it).apply()
        }
        Spacer(Modifier.height(14.dp)); Text("AJUSTE DE IMAGEN", color = Accent, fontWeight = FontWeight.Bold)
        listOf("FIT" to "Ajustar a pantalla", "ZOOM" to "Ampliar imagen", "FILL" to "Llenar pantalla").forEach { (key, label) ->
            Spacer(Modifier.height(8.dp)); RaptorOutlineButton(if (fitMode == key) "✓ $label" else label, {
                fitMode = key; prefs.edit().putString("player_fit", key).apply()
            }, Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(24.dp)); RaptorOutlineButton("VOLVER", onBack)
    }
}

@Composable
private fun InterfacePreferencesScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { settingsPrefs(context) }
    var textSize by rememberSaveable { mutableStateOf(prefs.getString("ui_text_size", "NORMAL") ?: "NORMAL") }
    var animations by rememberSaveable { mutableStateOf(prefs.getBoolean("ui_animations", true)) }
    var highContrast by rememberSaveable { mutableStateOf(prefs.getBoolean("ui_contrast", false)) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
        BrandHeader(); Spacer(Modifier.height(24.dp))
        Text("INTERFAZ Y ACCESIBILIDAD", fontSize = 23.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(8.dp)); Text("Personaliza las preferencias visuales.", color = TextMuted)
        Spacer(Modifier.height(18.dp)); Text("TAMAÑO DE TEXTO", color = Accent, fontWeight = FontWeight.Bold)
        listOf("SMALL" to "Pequeño", "NORMAL" to "Normal", "LARGE" to "Grande").forEach { (key, label) ->
            Spacer(Modifier.height(8.dp)); RaptorOutlineButton(if (textSize == key) "✓ $label" else label, {
                textSize = key; prefs.edit().putString("ui_text_size", key).apply()
            }, Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(14.dp))
        PreferenceRow("Animaciones", "Preferencia para futuras transiciones de pantalla", animations) {
            animations = it; prefs.edit().putBoolean("ui_animations", it).apply()
        }
        PreferenceRow("Contraste reforzado", "Guardar preferencia de accesibilidad", highContrast) {
            highContrast = it; prefs.edit().putBoolean("ui_contrast", it).apply()
        }
        Spacer(Modifier.height(16.dp)); Text("Las preferencias se guardan, pero el tamaño de texto, contraste y animaciones aún no se aplican globalmente a todas las pantallas.", color = TextMuted, fontSize = 12.sp)
        Spacer(Modifier.height(24.dp)); RaptorOutlineButton("VOLVER", onBack)
    }
}

@Composable
private fun PreferenceRow(title: String, description: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.height(4.dp)); Text(description, color = TextMuted, fontSize = 12.sp)
            }
            RaptorOutlineButton(if (checked) "ACTIVADO" else "DESACTIVADO", { onChange(!checked) })
        }
    }
}

@Composable
private fun SourcesScreen(
    onBack: () -> Unit, onXtream: () -> Unit, onM3u: () -> Unit,
    sources: List<IptvSource>, onPickM3uFile: () -> Unit, onDelete: (String) -> Unit, onOpenCatalog: (IptvSource) -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
        BrandHeader(); Spacer(Modifier.height(24.dp))
        Text("FUENTES IPTV", fontSize = 24.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(8.dp)); Text("Fuentes guardadas de forma persistente y cifrada: ${sources.size}", color = TextMuted)
        Spacer(Modifier.height(18.dp))
        FocusCard("Añadir Xtream Codes", "Servidor, usuario y contraseña", onXtream)
        Spacer(Modifier.height(10.dp)); FocusCard("Importar lista M3U/M3U8 por URL", "Descarga, validación y análisis de entradas", onM3u)
        Spacer(Modifier.height(10.dp)); FocusCard("Importar archivo M3U local", "Seleccionar un archivo del dispositivo", onPickM3uFile)
        Spacer(Modifier.height(18.dp))
        if (sources.isEmpty()) Text("Todavía no has añadido fuentes.", color = TextMuted)
        sources.forEach { source ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(source.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(when (source.type) {
                        SourceType.XTREAM -> "Xtream Codes · ${source.server} · ${source.itemCount} canales guardados"
                        SourceType.M3U_URL -> "M3U/M3U8 · ${source.itemCount} elementos analizados"
                        SourceType.M3U_FILE -> "Archivo M3U · ${source.itemCount} elementos"
                    }, color = TextMuted, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    if (source.type == SourceType.M3U_URL || source.type == SourceType.XTREAM || source.type == SourceType.M3U_FILE) {
                        RaptorButton(if (source.type == SourceType.XTREAM) "CONECTAR Y VER CANALES" else "VER CATÁLOGO", { onOpenCatalog(source) }, Modifier.fillMaxWidth())
                        Spacer(Modifier.height(6.dp))
                    }
                    RaptorOutlineButton("ELIMINAR FUENTE", { onDelete(source.id) })
                }
            }
        }
        Spacer(Modifier.height(14.dp)); RaptorOutlineButton("VOLVER", onBack)
    }
}


@Composable
private fun CatalogScreen(
    source: IptvSource?, entries: List<M3uEntry>, onPlay: (M3uEntry) -> Unit, onBack: () -> Unit,
    onRefresh: (IptvSource) -> Unit, onLoadMovies: (IptvSource) -> Unit,
    onLoadSeries: (IptvSource) -> Unit, busy: Boolean
) {
    var query by rememberSaveable { mutableStateOf("") }
    var groupFilter by rememberSaveable { mutableStateOf("") }
    val groups = remember(entries) { entries.map { it.group }.filter { it.isNotBlank() }.distinct().sorted() }
    val visible = remember(entries, query, groupFilter) {
        entries.filter { (query.isBlank() || it.name.contains(query, true) || it.group.contains(query, true)) &&
            (groupFilter.isBlank() || it.group == groupFilter) }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        BrandHeader(); Spacer(Modifier.height(20.dp))
        Text(source?.name ?: "CATÁLOGO", fontSize = 23.sp, fontWeight = FontWeight.Black)
        Text("${visible.size} de ${entries.size} elementos · listado local", color = TextMuted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        RaptorField("Buscar por nombre o grupo", query, { query = it })
        if (groups.isNotEmpty()) {
            Text("Grupos: ${groups.take(12).joinToString(" · ")}", color = TextMuted, fontSize = 11.sp)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RaptorOutlineButton(if (groupFilter.isBlank()) "TODOS ✓" else "TODOS", { groupFilter = "" })
                groups.take(4).forEach { group -> RaptorOutlineButton(if (groupFilter == group) "$group ✓" else group, { groupFilter = group }) }
            }
        }
        Spacer(Modifier.height(12.dp))
        if (entries.isEmpty()) {
            Text("Este catálogo no tiene elementos guardados. Vuelve a importar la lista.", color = TextMuted)
        } else if (visible.isEmpty()) {
            Text("No hay resultados para esa búsqueda.", color = TextMuted)
        } else {
            visible.take(1500).forEach { entry ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 7.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(entry.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        if (entry.group.isNotBlank()) Text(entry.group, color = Accent, fontSize = 11.sp)
                        Text(if (entry.tvgId.isNotBlank()) "ID: ${entry.tvgId}" else "Entrada IPTV", color = TextMuted, fontSize = 10.sp)
                        Spacer(Modifier.height(6.dp))
                        RaptorButton("▶ REPRODUCIR", { onPlay(entry) }, Modifier.fillMaxWidth())
                    }
                }
            }
            if (visible.size > 1500) Text("Se muestran los primeros 1500 resultados para mantener fluida la interfaz.", color = TextMuted, fontSize = 11.sp)
        }
        Spacer(Modifier.height(12.dp))
        source?.let { current ->
            if (current.type == SourceType.XTREAM) {
                RaptorButton(if (busy) "CONECTANDO…" else "CARGAR TV EN DIRECTO", { if (!busy) onRefresh(current) }, Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                RaptorOutlineButton(if (busy) "ESPERANDO…" else "CARGAR PELÍCULAS", { if (!busy) onLoadMovies(current) }, Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                RaptorOutlineButton(if (busy) "ESPERANDO…" else "CARGAR SERIES", { if (!busy) onLoadSeries(current) }, Modifier.fillMaxWidth())
            } else if (current.type == SourceType.M3U_URL) {
                RaptorButton(if (busy) "CONECTANDO…" else "ACTUALIZAR LISTA", { if (!busy) onRefresh(current) }, Modifier.fillMaxWidth())
            }
        }
        Spacer(Modifier.height(8.dp)); RaptorOutlineButton("VOLVER A FUENTES", onBack, Modifier.fillMaxWidth())
    }
}

@Composable
private fun SeriesDetailScreen(
    title: String,
    episodes: List<M3uEntry>,
    busy: Boolean,
    onPlay: (M3uEntry) -> Unit,
    onBack: () -> Unit
) {
    val seasons = remember(episodes) { episodes.map { it.group }.distinct().sorted() }
    var selectedSeason by rememberSaveable(title) { mutableStateOf("") }
    val activeSeason = selectedSeason.takeIf { it in seasons } ?: seasons.firstOrNull().orEmpty()
    val visibleEpisodes = episodes.filter { it.group == activeSeason }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        BrandHeader()
        Spacer(Modifier.height(20.dp))
        Text(title, fontSize = 23.sp, fontWeight = FontWeight.Black)
        Text("${episodes.size} episodios · ${seasons.size} temporadas", color = TextMuted, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        if (busy) CircularProgressIndicator(color = Accent)
        if (seasons.isNotEmpty()) {
            Text("TEMPORADAS", color = Accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            seasons.forEach { season ->
                RaptorOutlineButton(if (season == activeSeason) "$season ✓" else season, { selectedSeason = season }, Modifier.fillMaxWidth())
                Spacer(Modifier.height(5.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        if (episodes.isEmpty()) {
            Text("No se encontraron episodios. El proveedor puede no ofrecer temporadas o utilizar un formato de API diferente.", color = TextMuted)
        } else {
            visibleEpisodes.forEach { episode ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 7.dp)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(episode.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text(episode.group, color = TextMuted, fontSize = 11.sp)
                        }
                        Spacer(Modifier.width(8.dp))
                        RaptorButton("▶ VER", { onPlay(episode) })
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        RaptorOutlineButton("VOLVER A SERIES", onBack, Modifier.fillMaxWidth())
    }
}

@Composable
private fun PlayerScreen(entry: M3uEntry?, onBack: () -> Unit) {
    val context = LocalContext.current
    val activity = context as? Activity
    var fullscreen by rememberSaveable { mutableStateOf(false) }
    val originalOrientation = remember { activity?.requestedOrientation ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }
    DisposableEffect(fullscreen) {
        activity?.window?.decorView?.systemUiVisibility = if (fullscreen) (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        ) else View.SYSTEM_UI_FLAG_VISIBLE
        activity?.requestedOrientation = if (fullscreen) ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE else originalOrientation
        onDispose { }
    }
    DisposableEffect(activity) { onDispose {
        activity?.window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        activity?.requestedOrientation = originalOrientation
    } }
    var playbackError by remember(entry?.url) { mutableStateOf("") }
    var isBuffering by remember(entry?.url) { mutableStateOf(true) }
    val player = remember(entry?.url) {
        ExoPlayer.Builder(context).build().apply {
            addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    val httpError = generateSequence(error as Throwable?) { it.cause }
                        .filterIsInstance<HttpDataSource.InvalidResponseCodeException>()
                        .firstOrNull()
                    val httpDetail = httpError?.let { " HTTP ${it.responseCode}" }.orEmpty()
                    playbackError = "No se pudo reproducir este enlace (${error.errorCodeName}).$httpDetail Comprueba la URL, el formato y el acceso del proveedor."
                    isBuffering = false
                }
                override fun onPlaybackStateChanged(playbackState: Int) {
                    isBuffering = playbackState == Player.STATE_BUFFERING || playbackState == Player.STATE_IDLE
                }
            })
            entry?.url?.let { url ->
                setMediaItem(MediaItem.fromUri(url))
                playWhenReady = true
                prepare()
            }
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    Column(Modifier.fillMaxSize().background(Color.Black).padding(12.dp)) {
        if (!fullscreen) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RaptorOutlineButton("← VOLVER", onBack)
                Spacer(Modifier.width(12.dp))
                Text(entry?.name ?: "REPRODUCTOR", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = TextMain, maxLines = 2)
                Spacer(Modifier.weight(1f))
                RaptorOutlineButton("⛶", { fullscreen = true })
            }
            Spacer(Modifier.height(12.dp))
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                RaptorOutlineButton("SALIR DE PANTALLA COMPLETA", { fullscreen = false })
            }
        }
        AndroidView(
            factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true; keepScreenOn = true } },
            update = { it.player = player },
            modifier = Modifier.fillMaxWidth().weight(1f)
        )
        if (isBuffering && playbackError.isBlank()) {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(color = Accent, modifier = Modifier.height(20.dp).width(20.dp))
                Spacer(Modifier.width(8.dp)); Text("Conectando con la fuente…", color = TextMuted, fontSize = 12.sp)
            }
        }
        if (playbackError.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(playbackError, color = Accent, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text("Usa únicamente enlaces que tengas autorización para reproducir. La compatibilidad depende del formato y del servidor.", color = TextMuted, fontSize = 10.sp)
    }
}

@Composable
private fun XtreamScreen(onBack: () -> Unit, onSave: (String, String, String, String) -> Unit) {
    var label by rememberSaveable { mutableStateOf("Mi IPTV") }
    var server by rememberSaveable { mutableStateOf("") }
    var username by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
        BrandHeader(); Spacer(Modifier.height(24.dp)); Text("AÑADIR XTREAM CODES", fontSize = 22.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(14.dp))
        RaptorField("Nombre de la conexión", label, { label = it })
        RaptorField("URL del servidor (http/https)", server, { server = it })
        RaptorField("Usuario", username, { username = it })
        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Contraseña") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(12.dp))
        Text("Las credenciales se guardan cifradas. Al abrir la fuente, RAPTOR intentará validar el acceso y cargar los canales en directo.", color = TextMuted, fontSize = 12.sp)
        if (error.isNotBlank()) Text(error, color = Accent, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
        RaptorButton("GUARDAR FUENTE", {
            val valid = runCatching { val u = java.net.URL(server.trim()); u.protocol in listOf("http", "https") }.getOrDefault(false)
            error = when {
                label.isBlank() -> "Escribe un nombre para la fuente."
                !valid -> "Introduce una URL de servidor válida que use http:// o https://."
                username.isBlank() || password.isBlank() -> "Completa el usuario y la contraseña."
                else -> ""
            }
            if (error.isBlank()) onSave(label.trim(), server.trim(), username, password)
        }, Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp)); RaptorOutlineButton("CANCELAR", onBack, Modifier.fillMaxWidth())
    }
}

@Composable
private fun M3uScreen(busy: Boolean, onBack: () -> Unit, onSave: (String, String) -> Unit) {
    var label by rememberSaveable { mutableStateOf("Mi lista M3U") }
    var url by rememberSaveable { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
        BrandHeader(); Spacer(Modifier.height(24.dp)); Text("IMPORTAR LISTA M3U/M3U8", fontSize = 22.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(14.dp)); RaptorField("Nombre de la lista", label, { label = it }); RaptorField("URL de la lista", url, { url = it })
        Spacer(Modifier.height(12.dp)); Text("La aplicación descargará la lista y analizará sus entradas. Usa únicamente URLs de fuentes que tengas autorización para utilizar.", color = TextMuted, fontSize = 12.sp)
        if (error.isNotBlank()) Text(error, color = Accent, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
        RaptorButton(if (busy) "IMPORTANDO…" else "DESCARGAR E IMPORTAR", {
            val valid = runCatching { val u = java.net.URL(url.trim()); u.protocol in listOf("http", "https") }.getOrDefault(false)
            error = when { label.isBlank() -> "Escribe un nombre para la lista."; !valid -> "Introduce una URL http:// o https:// válida."; else -> "" }
            if (error.isBlank() && !busy) onSave(label.trim(), url.trim())
        }, Modifier.fillMaxWidth())
        if (busy) { Spacer(Modifier.height(12.dp)); CircularProgressIndicator(color = Accent) }
        Spacer(Modifier.height(10.dp)); RaptorOutlineButton("CANCELAR", onBack, Modifier.fillMaxWidth())
    }
}

@Composable
private fun RaptorField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = onValueChange, label = { Text(label) }, modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp), singleLine = true)
}

@Composable
private fun FocusCard(title: String, subtitle: String, onClick: () -> Unit) {
    var focused by rememberSaveable { mutableStateOf(false) }
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused }.focusable(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = if (focused) Color(0xFF29202A) else Panel),
        border = if (focused) BorderStroke(2.dp, Accent) else null
    ) {
        Row(Modifier.padding(horizontal = 18.dp, vertical = 17.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(4.dp)); Text(subtitle, color = TextMuted, fontSize = 12.sp)
            }
            Text("›", color = Accent, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun RaptorButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Button(onClick = onClick, modifier = modifier.height(50.dp), shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.White)) {
        Text(text, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
    }
}

@Composable
private fun RaptorOutlineButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    OutlinedButton(onClick = onClick, modifier = modifier.height(48.dp), shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, Color(0xFF4A5362)), colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMain)) {
        Text(text, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
    }
}

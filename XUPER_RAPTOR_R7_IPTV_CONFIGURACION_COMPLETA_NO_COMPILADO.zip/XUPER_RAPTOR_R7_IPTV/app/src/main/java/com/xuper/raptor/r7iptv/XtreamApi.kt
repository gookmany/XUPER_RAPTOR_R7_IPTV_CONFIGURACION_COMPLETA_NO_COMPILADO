package com.xuper.raptor.r7iptv

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Client for the standard Xtream Codes-compatible player API. Uses only credentials supplied by the user. */
object XtreamApi {
    data class Account(val status: String, val message: String, val expiry: String, val activeConnections: String)

    suspend fun testAndLoadLive(source: IptvSource): Pair<Account, List<M3uEntry>> =
        testAndLoadCatalog(source, "live")

    suspend fun testAndLoadMovies(source: IptvSource): Pair<Account, List<M3uEntry>> =
        testAndLoadCatalog(source, "movie")


    suspend fun testAndLoadSeries(source: IptvSource): Pair<Account, List<M3uEntry>> = withContext(Dispatchers.IO) {
        require(source.type == SourceType.XTREAM) { "La fuente no es Xtream Codes" }
        require(source.server.isNotBlank() && source.username.isNotBlank() && source.password.isNotBlank()) {
            "Faltan el servidor, el usuario o la contraseña"
        }
        val base = source.server.trim().trimEnd('/')
        val query = "username=${enc(source.username)}&password=${enc(source.password)}"
        val auth = getJson("$base/player_api.php?$query")
        val userInfo = auth.optJSONObject("user_info") ?: throw IllegalStateException("Respuesta Xtream no válida: falta user_info")
        val status = userInfo.optString("status", "unknown")
        if (!status.equals("Active", true) && !status.equals("Enabled", true)) {
            throw IllegalStateException("El servidor no indica una cuenta activa (estado: $status)")
        }
        val account = Account(status, "Conexión verificada", userInfo.optString("exp_date", ""), userInfo.optString("active_cons", ""))
        val series = getArray("$base/player_api.php?$query&action=get_series")
        val entries = buildList {
            for (i in 0 until series.length()) {
                val item = series.optJSONObject(i) ?: continue
                val id = item.optString("series_id").takeIf { it.isNotBlank() } ?: continue
                val name = item.optString("name").ifBlank { "Serie $id" }
                add(M3uEntry(
                    name = name,
                    url = "xtream-series://$id",
                    group = item.optString("category_name").ifBlank { "Series" },
                    logo = item.optString("cover"),
                    tvgId = id,
                    mediaType = "SERIES"
                ))
            }
        }
        account to entries
    }

    /** Loads episode stream URLs for one series using the standard get_series_info action. */
    suspend fun loadSeriesEpisodes(source: IptvSource, seriesId: String): Pair<String, List<M3uEntry>> = withContext(Dispatchers.IO) {
        require(source.type == SourceType.XTREAM) { "La fuente no es Xtream Codes" }
        require(seriesId.isNotBlank() && seriesId.all { it.isDigit() }) { "Identificador de serie no válido" }
        val base = source.server.trim().trimEnd('/')
        val query = "username=${enc(source.username)}&password=${enc(source.password)}"
        val info = getJson("$base/player_api.php?$query&action=get_series_info&series_id=${enc(seriesId)}")
        val infoObj = info.optJSONObject("info")
        val title = infoObj?.optString("name")?.takeIf { it.isNotBlank() } ?: "Serie $seriesId"
        val episodes = info.optJSONObject("episodes") ?: throw IllegalStateException("La respuesta no contiene episodios")
        val out = mutableListOf<M3uEntry>()
        val seasonKeys = episodes.keys()
        while (seasonKeys.hasNext()) {
            val seasonKey = seasonKeys.next()
            val seasonEpisodes = episodes.optJSONArray(seasonKey) ?: continue
            for (i in 0 until seasonEpisodes.length()) {
                val item = seasonEpisodes.optJSONObject(i) ?: continue
                val id = item.optString("id").takeIf { it.isNotBlank() } ?: continue
                val episodeTitle = item.optString("title").ifBlank { "Episodio $id" }
                val ext = item.optString("container_extension").ifBlank { "mp4" }
                val episodeUrl = "$base/series/${enc(source.username)}/${enc(source.password)}/$id.$ext"
                out += M3uEntry(
                    name = episodeTitle,
                    url = episodeUrl,
                    group = "Temporada $seasonKey · $title",
                    logo = item.optString("info").takeIf { it.startsWith("http") }.orEmpty(),
                    tvgId = item.optString("episode_num", id),
                    mediaType = "EPISODE"
                )
            }
        }
        title to out
    }

    private suspend fun testAndLoadCatalog(source: IptvSource, kind: String): Pair<Account, List<M3uEntry>> = withContext(Dispatchers.IO) {
        require(source.type == SourceType.XTREAM) { "La fuente no es Xtream Codes" }
        require(source.server.isNotBlank() && source.username.isNotBlank() && source.password.isNotBlank()) {
            "Faltan el servidor, el usuario o la contraseña"
        }
        val base = source.server.trim().trimEnd('/')
        val query = "username=${enc(source.username)}&password=${enc(source.password)}"
        val auth = getJson("$base/player_api.php?$query")
        val userInfo = auth.optJSONObject("user_info") ?: throw IllegalStateException("Respuesta Xtream no válida: falta user_info")
        val status = userInfo.optString("status", "unknown")
        if (!status.equals("Active", true) && !status.equals("Enabled", true)) {
            throw IllegalStateException("El servidor no indica una cuenta activa (estado: $status)")
        }
        val account = Account(status, "Conexión verificada", userInfo.optString("exp_date", ""), userInfo.optString("active_cons", ""))
        val action = if (kind == "movie") "get_vod_streams" else "get_live_streams"
        val streams = getArray("$base/player_api.php?$query&action=$action")
        val entries = buildList {
            for (i in 0 until streams.length()) {
                val item = streams.optJSONObject(i) ?: continue
                val idKey = if (kind == "movie") "stream_id" else "stream_id"
                // JSONObject can stringify JSON null as the literal "null". Never treat it as an ID.
                val id = item.optString(idKey).trim().takeUnless { it.isBlank() || it.equals("null", true) } ?: continue
                val name = item.optString("name").ifBlank { if (kind == "movie") "Película $id" else "Canal $id" }
                val ext = item.optString("container_extension").ifBlank { if (kind == "movie") "mp4" else "ts" }
                val category = item.optString("category_name").ifBlank { if (kind == "movie") "Películas" else "TV en directo" }
                // Credentials are path segments here, not query parameters. URLEncoder turns spaces
                // into '+', which is not the correct escaping rule for URL path segments.
                val userPath = encodePathSegment(source.username)
                val passwordPath = encodePathSegment(source.password)
                val streamUrl = if (kind == "movie")
                    "$base/movie/$userPath/$passwordPath/$id.$ext"
                else "$base/live/$userPath/$passwordPath/$id.$ext"
                val epgId = item.optString("epg_channel_id").trim()
                    .takeUnless { it.isBlank() || it.equals("null", true) }
                // Keep a useful identifier visible even when the provider has no EPG ID.
                val displayId = epgId ?: id
                add(M3uEntry(name = name, url = streamUrl, group = category,
                    logo = item.optString("stream_icon").takeUnless { it.equals("null", true) }.orEmpty(),
                    tvgId = displayId, mediaType = if (kind == "movie") "MOVIE" else "LIVE"))
            }
        }
        account to entries
    }

    private fun getJson(address: String): JSONObject {
        val text = request(address)
        return JSONObject(text)
    }

    private fun getArray(address: String): JSONArray = JSONArray(request(address))

    private fun request(address: String): String {
        val url = URL(address)
        require(url.protocol.equals("https", true) || url.protocol.equals("http", true)) { "El servidor debe usar HTTP o HTTPS" }
        val connection = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 12_000
            readTimeout = 25_000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "XUPER-RAPTOR-R7-IPTV/0.4")
            instanceFollowRedirects = true
        }
        try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("Servidor Xtream respondió HTTP $code")
            if (body.isBlank()) throw IllegalStateException("El servidor Xtream devolvió una respuesta vacía")
            return body
        } finally { connection.disconnect() }
    }

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    private fun encodePathSegment(value: String): String =
        URLEncoder.encode(value, "UTF-8").replace("+", "%20")
}

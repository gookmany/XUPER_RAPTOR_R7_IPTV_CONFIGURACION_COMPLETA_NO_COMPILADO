package com.xuper.raptor.r7iptv

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.database.Cursor
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.Reader
import java.io.StringReader
import java.util.UUID

/** Supported user-configured IPTV source types. */
enum class SourceType { XTREAM, M3U_URL, M3U_FILE }

data class IptvSource(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: SourceType,
    val server: String = "",
    val username: String = "",
    val password: String = "",
    val url: String = "",
    val itemCount: Int = 0
)

data class M3uEntry(
    val name: String,
    val url: String,
    val group: String = "",
    val logo: String = "",
    val tvgId: String = "",
    val mediaType: String = "LIVE"
)

/** Source credentials remain encrypted; large catalogs are stored in SQLite, not SharedPreferences. */
class IptvSourceRepository(context: Context) {
    private val appContext = context.applicationContext
    private val prefs by lazy {
        val masterKey = MasterKey.Builder(appContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            appContext, "raptor_iptv_sources_secure", masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }
    private val catalogDb by lazy { CatalogDatabase(appContext) }

    @Synchronized fun getAll(): List<IptvSource> {
        val raw = prefs.getString(KEY_SOURCES, "[]") ?: "[]"
        val json = JSONArray(raw)
        return (0 until json.length()).mapNotNull { i -> runCatching {
            val o = json.getJSONObject(i)
            IptvSource(
                id = o.getString("id"), name = o.getString("name"),
                type = SourceType.valueOf(o.getString("type")),
                server = o.optString("server"), username = o.optString("username"),
                password = o.optString("password"), url = o.optString("url"),
                itemCount = o.optInt("itemCount", 0)
            )
        }.getOrNull() }
    }

    @Synchronized fun save(source: IptvSource) {
        val list = getAll().filterNot { it.id == source.id } + source
        val json = JSONArray()
        list.forEach { s -> json.put(JSONObject().apply {
            put("id", s.id); put("name", s.name); put("type", s.type.name)
            put("server", s.server); put("username", s.username); put("password", s.password)
            put("url", s.url); put("itemCount", s.itemCount)
        }) }
        prefs.edit().putString(KEY_SOURCES, json.toString()).apply()
    }

    /** Replaces a catalog atomically in SQLite; the previous catalog survives a failed write. */
    @Synchronized fun saveEntries(sourceId: String, entries: List<M3uEntry>) {
        val db = catalogDb.writableDatabase
        db.beginTransaction()
        try {
            db.delete(TABLE_ENTRIES, "source_id = ?", arrayOf(sourceId))
            val statement = db.compileStatement(
                "INSERT INTO $TABLE_ENTRIES (source_id, name, url, group_name, logo, tvg_id, media_type) VALUES (?, ?, ?, ?, ?, ?, ?)"
            )
            entries.forEach { entry ->
                statement.clearBindings()
                statement.bindString(1, sourceId); statement.bindString(2, entry.name)
                statement.bindString(3, entry.url); statement.bindString(4, entry.group)
                statement.bindString(5, entry.logo); statement.bindString(6, entry.tvgId)
                statement.bindString(7, entry.mediaType)
                statement.executeInsert()
            }
            statement.close()
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    @Synchronized fun getEntries(sourceId: String): List<M3uEntry> {
        val result = ArrayList<M3uEntry>()
        catalogDb.readableDatabase.query(
            TABLE_ENTRIES, arrayOf("name", "url", "group_name", "logo", "tvg_id", "media_type"),
            "source_id = ?", arrayOf(sourceId), null, null, "id ASC"
        ).use { cursor ->
            while (cursor.moveToNext()) result += M3uEntry(
                cursor.getString(0), cursor.getString(1), cursor.getString(2),
                cursor.getString(3), cursor.getString(4), cursor.getString(5)
            )
        }
        // One-time best-effort migration from catalogs written by older versions.
        if (result.isEmpty()) {
            val legacy = prefs.getString("catalog_$sourceId", null)
            if (!legacy.isNullOrBlank()) runCatching {
                val json = JSONArray(legacy)
                val old = (0 until json.length()).mapNotNull { i -> runCatching {
                    val o = json.getJSONObject(i)
                    M3uEntry(o.getString("name"), o.getString("url"), o.optString("group"), o.optString("logo"), o.optString("tvgId"), o.optString("mediaType", "LIVE"))
                }.getOrNull() }
                if (old.isNotEmpty()) { saveEntries(sourceId, old); prefs.edit().remove("catalog_$sourceId").apply(); return old }
            }
        }
        return result
    }

    @Synchronized fun delete(id: String) {
        val json = JSONArray()
        getAll().filterNot { it.id == id }.forEach { s -> json.put(JSONObject().apply {
            put("id", s.id); put("name", s.name); put("type", s.type.name)
            put("server", s.server); put("username", s.username); put("password", s.password)
            put("url", s.url); put("itemCount", s.itemCount)
        }) }
        prefs.edit().putString(KEY_SOURCES, json.toString()).remove("catalog_$id").apply()
        catalogDb.writableDatabase.delete(TABLE_ENTRIES, "source_id = ?", arrayOf(id))
    }

    private class CatalogDatabase(context: Context) : SQLiteOpenHelper(context, "raptor_catalog.db", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE $TABLE_ENTRIES (id INTEGER PRIMARY KEY AUTOINCREMENT, source_id TEXT NOT NULL, name TEXT NOT NULL, url TEXT NOT NULL, group_name TEXT NOT NULL, logo TEXT NOT NULL, tvg_id TEXT NOT NULL, media_type TEXT NOT NULL)")
            db.execSQL("CREATE INDEX idx_catalog_source ON $TABLE_ENTRIES(source_id, id)")
        }
        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) { }
    }

    private companion object {
        const val KEY_SOURCES = "sources_json"
        const val TABLE_ENTRIES = "catalog_entries"
    }
}

object M3uParser {
    /** Parses standard #EXTM3U / #EXTINF entries and common IPTV attributes. */
    fun parse(text: String): List<M3uEntry> = parse(StringReader(text))

    /** Streaming line parser: does not create a second in-memory copy of the entire playlist. */
    fun parse(reader: Reader): List<M3uEntry> {
        val entries = ArrayList<M3uEntry>()
        var pendingName: String? = null
        var pendingGroup = ""
        var pendingLogo = ""
        var pendingId = ""
        reader.buffered().useLines { lines -> lines.forEachIndexed { index, rawLine ->
            val line = if (index == 0) rawLine.removePrefix("\uFEFF").trim() else rawLine.trim()
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    val comma = line.indexOf(',')
                    val attrs = line.substringBeforeLast(",", line)
                    pendingName = if (comma >= 0 && comma < line.lastIndex) line.substring(comma + 1).trim() else "Canal sin nombre"
                    pendingGroup = attr(attrs, "group-title")
                    pendingLogo = attr(attrs, "tvg-logo")
                    pendingId = attr(attrs, "tvg-id")
                }
                line.isNotEmpty() && !line.startsWith("#") && pendingName != null -> {
                    val name = pendingName!!.ifBlank { line }
                    entries += M3uEntry(name, line, pendingGroup, pendingLogo, pendingId, inferMediaType(name, pendingGroup, line))
                    pendingName = null; pendingGroup = ""; pendingLogo = ""; pendingId = ""
                }
            }
        } }
        return entries
    }

    /** Best-effort classification; M3U playlists do not define a universal media-type field. */
    private fun inferMediaType(name: String, group: String, address: String): String {
        val metadata = "$name $group".lowercase(java.util.Locale.ROOT)
        val path = runCatching { URL(address).path.lowercase(java.util.Locale.ROOT) }
            .getOrDefault(address.lowercase(java.util.Locale.ROOT))
        val seriesWords = listOf("series", "serie", "temporada", "episodio", "episode", "season")
        if (seriesWords.any { metadata.contains(it) } || Regex("[sS]\\d{1,2}[eE]\\d{1,3}").containsMatchIn(name)) return "SERIES"
        val movieWords = listOf("movie", "movies", "pelicula", "película", "cinema", "vod", "film")
        if (movieWords.any { metadata.contains(it) } || listOf(".mkv", ".mp4", ".avi", ".mov").any { path.endsWith(it) }) return "MOVIE"
        return "LIVE"
    }

    private fun attr(line: String, key: String): String {
        val regex = Regex("(?:^|\\s)${Regex.escape(key)}=\\\"([^\\\"]*)\\\"", RegexOption.IGNORE_CASE)
        return regex.find(line)?.groupValues?.getOrNull(1).orEmpty()
    }
}

object M3uDownloader {
    suspend fun downloadAndParse(address: String): List<M3uEntry> = withContext(Dispatchers.IO) {
        val url = URL(address)
        require(url.protocol.equals("https", true) || url.protocol.equals("http", true)) { "La URL debe comenzar por http:// o https://" }
        val connection = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 12_000; readTimeout = 20_000; requestMethod = "GET"
            setRequestProperty("User-Agent", "XUPER-RAPTOR-R7-IPTV/0.2")
        }
        try {
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("El servidor respondió HTTP $code")
            val contentType = connection.contentType.orEmpty()
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (body.isBlank()) throw IllegalStateException("La lista descargada está vacía")
            if (!body.trimStart().startsWith("#EXTM3U", true) && !contentType.contains("mpegurl", true)) {
                throw IllegalStateException("La respuesta no parece ser una lista M3U válida")
            }
            val entries = M3uParser.parse(body)
            if (entries.isEmpty()) throw IllegalStateException("No se encontraron canales o elementos en la lista")
            entries
        } finally { connection.disconnect() }
    }
}

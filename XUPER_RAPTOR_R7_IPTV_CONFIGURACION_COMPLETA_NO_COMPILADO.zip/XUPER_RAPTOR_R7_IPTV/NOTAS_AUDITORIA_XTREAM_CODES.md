# Auditoría y corrección de Xtream Codes

## Hallazgos en el código revisado

- La carga de canales en directo consulta `get_live_streams` y construye enlaces con `/live/usuario/contraseña/stream_id.ts` (o la extensión que devuelva el servidor).
- La interfaz utilizaba `epg_channel_id` como ID visible. Algunos proveedores devuelven ese campo ausente o como JSON `null`, que puede terminar representado como el texto `null`. Ahora se normaliza y, si falta, se muestra el `stream_id`.
- Las credenciales se insertan en segmentos de la ruta. `URLEncoder` por sí solo codifica espacios como `+`, lo cual corresponde a formularios/consultas, no a segmentos de ruta. Se añadió codificación de segmento para las credenciales en URLs de reproducción.
- El reproductor ahora intenta mostrar el código HTTP concreto cuando Media3 informa un `InvalidResponseCodeException` (por ejemplo, 401, 403 o 404), para diferenciar una respuesta del servidor de otros fallos de reproducción.
- El listener del reproductor se registra antes de llamar a `prepare()`.

## Límites de la verificación

Estos cambios corrigen problemas observables en el código, pero no prueban que el proveedor acepte la URL resultante. Un error HTTP puede deberse a credenciales, permisos, enlaces caducados, una ruta o extensión específica del proveedor, o restricciones del servidor. Para confirmar la causa real hay que probar con una cuenta y un enlace autorizados y observar el código HTTP resultante.

El proyecto no se ha compilado en este entorno porque no hay una instalación de Gradle/Android SDK disponible para ejecutar una compilación Android verificable. No se afirma que el APK haya sido probado.

# Etapa 2.9 — Catálogo de películas Xtream Codes (0.7.0)

## Incluido en el código
- Método `testAndLoadMovies` que consulta `player_api.php?action=get_vod_streams` después de comprobar `user_info` y el estado de la cuenta.
- Construcción de URL de reproducción de películas con la ruta `/movie/usuario/contraseña/stream_id.ext` y extensión devuelta por el proveedor (con `mp4` como valor por defecto).
- Botón **CARGAR PELÍCULAS** en el catálogo de una fuente Xtream.
- Persistencia del tipo de contenido (`LIVE` o `MOVIE`) junto a cada entrada.
- El catálogo comparte búsqueda y filtro por grupo con la pantalla existente; al seleccionar reproducir, se usa Media3.
- Versión Android actualizada a `versionCode 7`, `versionName 0.7.0`.

## Limitaciones
- La API Xtream varía entre proveedores y no todos ofrecen `get_vod_streams` o los mismos campos.
- No se implementaron todavía metadatos enriquecidos, carátulas renderizadas, categorías de series ni temporadas/episodios.
- La autenticación y reproducción con un proveedor real no se han probado.
- No se generó APK: el entorno no tiene Android SDK/Gradle instalados. El ZIP solo distribuye el código fuente.

## Verificación efectuada
- Se revisó la estructura del proyecto y los cambios de serialización del modelo.
- Se debe abrir en Android Studio con JDK 17 y Android SDK 35, sincronizar Gradle, compilar e instalar para completar la validación.

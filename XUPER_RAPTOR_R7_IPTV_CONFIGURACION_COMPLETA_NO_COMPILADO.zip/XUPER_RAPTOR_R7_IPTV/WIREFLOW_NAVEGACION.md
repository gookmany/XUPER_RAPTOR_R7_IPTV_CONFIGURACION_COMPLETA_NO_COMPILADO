# XUPER RAPTOR R7 IPTV — Wireflow de navegación v1

## Objetivo
Definir transiciones previsibles para TV Box (D-pad/OK/Back), móvil y tablet. La bienvenida de referencia se conserva como concepto visual; la aplicación usa marca y código propios.

## Rutas principales

```text
App launch
  └─ Welcome / comprobación local
       ├─ configuración válida y fuente activa → Home
       ├─ sin fuente → Home en estado vacío (no bloquea)
       └─ fallo recuperable → Home + aviso no intrusivo

Home
  ├─ LIVE → selector de fuente/categoría → lista de canales → reproductor
  ├─ FEATURED → colección recomendada (si hay metadatos)
  ├─ MOVIES → catálogo → detalle → reproducir
  ├─ SERIES → catálogo → detalle → temporada/episodio → reproducir
  ├─ KIDS → catálogo filtrado (si hay metadatos)
  ├─ ANIME → catálogo filtrado (si hay metadatos)
  ├─ EXPLORAR → búsqueda y filtros globales
  └─ ⚙ Configuración
       ├─ Fuentes IPTV
       │    ├─ Añadir Xtream Codes → formulario → probar → importar catálogo
       │    ├─ Añadir URL M3U/M3U8 → formulario → analizar → importar
       │    ├─ Importar archivo → selector de documentos → analizar → importar
       │    └─ Gestionar fuentes → activar / editar / actualizar / eliminar
       ├─ Reproductor
       ├─ Interfaz y accesibilidad
       ├─ Control parental (opcional, con PIN)
       └─ Acerca de
```

## Reglas de navegación
- **Atrás en pantalla secundaria:** vuelve a la pantalla anterior sin perder formularios no confirmados; pregunta antes de descartar cambios.
- **Atrás en reproductor:** cierra controles/pantalla completa primero; luego vuelve al catálogo. No detener reproducción accidentalmente al ocultar controles.
- **Atrás en Home:** en TV no cierra de inmediato; muestra confirmación de salida si no existe otra pantalla en la pila. En móvil sigue la convención Android.
- **OK/Enter:** activa el elemento enfocado. El foco debe ser visible con contraste y no depender solo del color.
- **D-pad:** foco secuencial; al cambiar de categoría, conservar el último elemento enfocado cuando sea posible.
- **Touch:** tarjetas y acciones tienen área táctil suficiente; los formularios permiten teclado del sistema.
- **Rotación/cambio de tamaño:** preservar pantalla, fuente seleccionada y posición del catálogo.

## Estados que cada pantalla debe representar
1. **Inicial:** aún no se ha consultado la fuente local.
2. **Cargando:** actividad real en curso; incluir cancelar cuando sea seguro.
3. **Contenido:** mostrar datos recibidos.
4. **Vacío:** explicación y acción concreta (añadir fuente, limpiar filtros, actualizar).
5. **Error recuperable:** mensaje comprensible, reintentar y editar configuración.
6. **Sin conexión:** mantener caché utilizable cuando sea posible y señalar que puede estar desactualizada.

## Flujos de configuración de fuente

### Xtream
1. Nombre opcional de la conexión.
2. URL base del servidor, usuario y contraseña.
3. Validación local de campos; normalizar URL sin inventar rutas.
4. Botón “Probar conexión”.
5. Mostrar resultado sin exponer la contraseña ni la URL completa con credenciales.
6. Si funciona, permitir importar LIVE/VOD/SERIES según capacidades reportadas.
7. Guardar credenciales en almacenamiento protegido; no registrar secretos en logs.

### M3U/M3U8
1. Elegir URL o archivo local.
2. Descargar/leer de forma limitada y cancelable; aplicar límites de tamaño/tiempo.
3. Analizar en segundo plano y mostrar cantidad de entradas válidas/ignoradas.
4. Confirmar nombre de fuente y actualización automática opcional.
5. Guardar metadatos de fuente y caché; no confiar en enlaces externos sin validación.

## Criterios de aceptación
- El inicio no queda esperando una conexión IPTV indefinidamente.
- Se puede entrar a Home sin configurar fuente.
- Cada operación de red tiene timeout, cancelación cuando aplique y estado de error.
- Nunca se muestra contraseña en claro tras guardar.
- Eliminar fuente borra sus credenciales y datos relacionados previa confirmación.
- El foco del mando es claramente visible en todos los controles interactivos.
- Los catálogos vacíos y errores no dejan pantallas negras sin explicación.

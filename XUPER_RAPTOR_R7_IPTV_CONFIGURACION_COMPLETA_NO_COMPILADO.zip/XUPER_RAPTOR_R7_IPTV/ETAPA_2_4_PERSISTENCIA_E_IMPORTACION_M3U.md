# Etapa 2.4 — Persistencia de fuentes e importación M3U

## Implementado en el código fuente

- Registro de fuentes persistente entre reinicios usando preferencias cifradas respaldadas por Android Keystore (`EncryptedSharedPreferences`).
- Tipos de fuente definidos: Xtream Codes, M3U/M3U8 por URL y archivo M3U (este último está modelado, pero el selector de archivos todavía no está conectado).
- Guardado y eliminación de fuentes desde la interfaz.
- Validación inicial de los campos de Xtream Codes. Las credenciales se guardan cifradas; el cliente aún no comprueba si el servidor las acepta.
- Descarga HTTP/HTTPS de listas M3U en un contexto de entrada/salida, con límites de conexión/lectura, verificación del código HTTP y comprobaciones básicas de formato.
- Analizador de `#EXTINF` para extraer nombre, `group-title`, `tvg-logo`, `tvg-id` y URL de cada entrada.
- La interfaz informa cuántos elementos fueron detectados. Esto no significa que esos elementos ya se puedan reproducir.

## Limitaciones conocidas

- La conexión real de Xtream Codes y la consulta de categorías/canales todavía no están implementadas.
- Las entradas M3U se analizan durante la importación, pero la lista completa de entradas todavía no se persiste ni se muestra como catálogo. Se guarda el origen y el número de entradas detectadas.
- No hay reproductor multimedia integrado en esta etapa.
- No está conectado el selector de archivos locales M3U.
- La dependencia AndroidX Security Crypto usada aquí es una API en fase alpha; debe evaluarse/actualizarse antes de una versión de producción.
- No se ha podido compilar ni ejecutar este proyecto en el entorno de trabajo porque no se detectó instalación de Gradle ni Android SDK. La compilación y pruebas en dispositivo quedan pendientes.

## Pruebas manuales recomendadas cuando se abra en Android Studio

1. Compilar `:app:assembleDebug` con JDK 17 y Android SDK 35.
2. Añadir una URL M3U válida autorizada y verificar que el recuento coincida con las entradas `#EXTINF`.
3. Probar una URL inexistente, HTTP 404, respuesta vacía y texto que no sea M3U; debe mostrarse un error y no guardarse una fuente nueva.
4. Añadir una fuente Xtream y reiniciar la aplicación; debe seguir en la lista.
5. Eliminar una fuente y reiniciar; no debe reaparecer.
6. Verificar en dispositivos reales Android móvil, tablet y TV Box, incluida navegación por mando/teclado.

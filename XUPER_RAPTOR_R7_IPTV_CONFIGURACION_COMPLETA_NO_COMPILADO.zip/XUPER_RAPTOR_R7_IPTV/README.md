# XUPER RAPTOR R7 IPTV — fuente Android

Versión del proyecto: **1.0.0**.

Base Kotlin + Jetpack Compose para Android móvil, tablet y Android TV/TV Box.

## Funciones en el código
- Bienvenida y navegación principal.
- Configuración y administración de fuentes.
- Guardado cifrado de credenciales y metadatos de fuentes.
- Descarga, análisis y catálogo local de listas M3U/M3U8 por URL.
- Conector Xtream Codes compatible con el API habitual: validación de cuenta y carga de canales en directo.
- Búsqueda local y filtrado básico de entradas del catálogo.
- Reproductor integrado con AndroidX Media3/ExoPlayer, controles nativos, pantalla de reproducción y visualización de errores.
- Modo de pantalla completa con orientación horizontal durante la reproducción.
- Importación de archivo M3U local mediante el selector de documentos de Android.

## Aún pendiente
- Catálogo Xtream de películas y series.
- Catálogo Xtream de películas y series.
- Categorías y catálogo Xtream de películas y series.
- EPG, favoritos y controles parentales.
- Pruebas automatizadas y compilación verificada.

## Abrir
1. Descomprime el proyecto.
2. Abre la carpeta raíz en Android Studio reciente.
3. Usa JDK 17 y Android SDK 35.
4. Sincroniza Gradle y compila.
5. Prueba con una fuente IPTV que estés autorizado a utilizar.

**Estado de validación:** el código fuente se ha preparado, pero no se afirma que compile o que haya sido probado en dispositivo. Revisa los errores de Gradle/Android Studio antes de instalar.

**Nota de red:** se permite tráfico HTTP claro para compatibilidad con listas y servidores IPTV que no ofrecen HTTPS. Cuando sea posible, utiliza HTTPS; las conexiones HTTP no cifran el tráfico durante el transporte.


## Etapa 2.9 (versión 0.7.0)
Se agregó la consulta de películas Xtream (`get_vod_streams`) y el botón CARGAR PELÍCULAS en el catálogo. Ver `ETAPA_2_9_CATALOGO_PELICULAS_XTREAM.md`. La compilación y las pruebas con servidor real siguen pendientes.


## Etapa 2.10 — versión 0.9.0

Se añadió el catálogo Xtream de series, consulta de detalle/episodios, selección de temporada y lanzamiento de episodios al reproductor. Consulta `ETAPA_2_10_SERIES_TEMPORADAS_EPISODIOS.md`. La compilación y la reproducción real siguen pendientes de verificación.


## Etapa 2.11 (v0.9.0)
Las categorías de Inicio abren el catálogo de la primera fuente configurada. Para Xtream, LIVE/MOVIES/SERIES consultan sus acciones de catálogo; en listas M3U y datos locales se aplican filtros por tipo y palabras clave. Consulta `ETAPA_2_11_NAVEGACION_CATEGORIAS.md`. La compilación Android continúa pendiente de verificación.


## Etapa 2.12 — versión 1.0.0
Se mejoró el análisis M3U para inferir, de forma heurística, si una entrada corresponde a LIVE, MOVIE o SERIES según nombre, grupo y extensión de URL. Esto mejora los filtros de inicio, pero no puede clasificar con certeza listas que no incluyan metadatos descriptivos. Se actualizó el versionado Android. La compilación y las pruebas de reproducción siguen pendientes. Ver `ETAPA_2_12_CLASIFICACION_M3U_Y_PREPARACION_1_0_0.md`.

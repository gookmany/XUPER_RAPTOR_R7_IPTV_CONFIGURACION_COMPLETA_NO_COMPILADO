# Etapa 2.12 — clasificación de M3U y preparación de versión 1.0.0

## Cambios
- El analizador M3U intenta clasificar cada entrada como `LIVE`, `MOVIE` o `SERIES` usando el nombre, el grupo y la extensión de la URL.
- Reconoce palabras comunes en español e inglés (por ejemplo, película/movie, serie/series, temporada/season) y patrones de episodios como S01E02.
- Se actualizó `versionCode` a 10 y `versionName` a `1.0.0`.
- Se actualizó el rótulo de versión de la interfaz y el README.

## Límites
La clasificación es heurística: una lista puede llamar a un canal “Movie Channel” o usar grupos ambiguos. No se debe asumir que todos los elementos quedan clasificados correctamente. Las listas M3U no tienen un campo de tipo universal obligatorio.

## Verificación
- Revisión estática del cambio realizada.
- No se ejecutó Gradle: en el entorno disponible no se encontró el ejecutable `gradle` ni una configuración `ANDROID_HOME` válida.
- No se afirma que el APK compile ni que se haya probado en dispositivo.

## Próximas pruebas recomendadas
1. Compilar en Android Studio con JDK 17 y SDK Android 35.
2. Probar listas M3U con grupos de TV, películas, series, anime y contenido infantil.
3. Revisar manualmente falsos positivos/negativos de clasificación.
4. Probar reproducción con enlaces autorizados HTTP/HTTPS y formatos soportados por Media3.

# ETAPA 2.10 — Series, temporadas y episodios Xtream Codes

## Implementado en el código fuente

- Añadido `get_series` al cliente Xtream Codes compatible.
- Cada serie se representa como un elemento de catálogo con su identificador, nombre, categoría y carátula cuando el servidor la proporciona.
- Añadido `get_series_info` para consultar temporadas y episodios de una serie.
- Construcción de URL de episodio en el patrón estándar `/series/usuario/contraseña/ID.ext`.
- Nueva pantalla de detalle de serie con selección de temporada y lista de episodios.
- Los episodios pueden enviarse al reproductor Media3 desde su ficha.
- Versión de aplicación actualizada a `0.8.0`.

## Flujo de uso

1. Abrir una fuente Xtream Codes.
2. Pulsar **CARGAR SERIES**.
3. Seleccionar una serie en el catálogo.
4. La aplicación consulta `get_series_info` y presenta los episodios agrupados por temporada.
5. Pulsar **VER** para abrir un episodio en el reproductor.

## Límites y validación

- El código usa las acciones habituales de la API Xtream Codes; los proveedores pueden variar en los campos devueltos y en sus rutas de reproducción.
- No se han usado credenciales reales ni se ha contactado con ningún proveedor durante esta etapa.
- No se ha podido ejecutar una compilación Gradle/Android en este entorno porque no hay Gradle ni Android SDK instalados.
- La creación de URL de episodio y la reproducción real necesitan pruebas con una cuenta autorizada.
- Las credenciales se envían al servidor configurado por el usuario. Se recomienda HTTPS; los servidores HTTP no cifran esas credenciales en tránsito.

## Próxima etapa sugerida

Compilar e instalar en Android y corregir errores reales de build; después probar una fuente Xtream autorizada para validar respuesta de series, temporadas, extensiones y reproducción.

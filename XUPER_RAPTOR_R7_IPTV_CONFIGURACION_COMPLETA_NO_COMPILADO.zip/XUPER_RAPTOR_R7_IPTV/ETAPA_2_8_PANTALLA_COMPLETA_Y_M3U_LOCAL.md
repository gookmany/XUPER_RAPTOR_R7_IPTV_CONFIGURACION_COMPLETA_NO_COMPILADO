# Etapa 2.8 — pantalla completa e importación M3U local

Versión de código: **0.6.0**.

## Cambios incluidos
- Añadida selección de archivo M3U mediante el selector de documentos de Android (SAF); no requiere permiso general de almacenamiento.
- El archivo se lee, analiza con el parser M3U existente y sus entradas se guardan en el catálogo local cifrado.
- Las fuentes M3U locales aparecen en la lista y permiten abrir su catálogo.
- Añadido control para activar pantalla completa y orientación horizontal durante la reproducción; al salir del reproductor se restaura la orientación anterior y la visibilidad de barras del sistema.
- Incrementada la versión Android a 0.6.0.

## Límites y validación
- La importación admite M3U en texto plano compatible con el parser actual; listas muy grandes pueden consumir memoria al leerlas completas.
- El selector usa tipos MIME habituales; algunos gestores de archivos pueden requerir elegir “Todos los archivos”.
- La pantalla completa usa APIs de sistema antiguas pero disponibles para el minSdk del proyecto; se recomienda migrar a WindowInsetsController en una fase de compatibilidad.
- No se ha verificado una compilación ni una ejecución real en Android en este entorno. El ZIP se comprobará estructuralmente, lo cual no demuestra que Gradle compile.

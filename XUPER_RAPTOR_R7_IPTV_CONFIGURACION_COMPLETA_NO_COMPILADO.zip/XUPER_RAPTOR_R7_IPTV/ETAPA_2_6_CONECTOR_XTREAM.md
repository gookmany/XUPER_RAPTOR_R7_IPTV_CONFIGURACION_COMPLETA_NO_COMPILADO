# Etapa 2.6 — Conector Xtream Codes (0.4.0)

## Implementado en el código fuente
- Cliente `XtreamApi` para API compatible con Xtream Codes.
- Comprueba la respuesta de `player_api.php` y el campo `user_info.status`.
- Consulta `action=get_live_streams` y convierte los canales en entradas del catálogo existente.
- Conserva nombre, categoría, logo e ID EPG cuando el servidor los devuelve.
- Construye la URL estándar de reproducción para cada canal, sin iniciar todavía el reproductor.
- UI: desde Fuentes IPTV se puede conectar y abrir el catálogo; el catálogo permite volver a probar/actualizar canales.
- Se conservan credenciales cifradas con Android Keystore mediante EncryptedSharedPreferences.

## Límites conocidos
- Solo se cargan canales en directo. Categorías oficiales separadas, VOD, series, EPG y búsqueda en el servidor aún no están implementados.
- No se reproduce todavía vídeo ni audio; las URL se guardan como metadatos.
- Algunas plataformas modifican el API estándar y podrían requerir compatibilidad adicional.
- Las solicitudes usan HTTP o HTTPS según el servidor indicado. Se recomienda HTTPS; el servidor HTTP transmite credenciales sin cifrado de transporte.
- El código no ha sido compilado ni ejecutado en un dispositivo en este entorno. Requiere revisión y pruebas en Android Studio.

# Etapa 2.7 — Reproductor Media3/ExoPlayer (0.5.0)

## Implementado en el código fuente
- Añadidas dependencias AndroidX Media3 ExoPlayer y Media3 UI 1.5.1.
- Añadida pantalla de reproducción con `PlayerView` y controles nativos.
- Las filas del catálogo tienen un botón **REPRODUCIR** que abre la pantalla del reproductor.
- El reproductor prepara el enlace del elemento seleccionado y libera el recurso al salir de la pantalla.
- Se muestran estado de carga y errores de reproducción para facilitar el diagnóstico.
- Se conserva el botón para regresar al catálogo.
- `versionCode=5`, `versionName=0.5.0`.

## Límites conocidos
- No se ha compilado ni ejecutado en este entorno; las dependencias y el código requieren sincronización y verificación en Android Studio.
- La compatibilidad depende del códec, contenedor, protocolo, DRM y restricciones del proveedor. No todas las URLs M3U son reproducibles directamente.
- No se ha implementado todavía el modo de pantalla completa/orientación, EPG, favoritos, historial, ni catálogo VOD/series de Xtream.
- Se habilitó tráfico HTTP claro para soportar proveedores/listas HTTP. Esto reduce la seguridad de transporte; preferir HTTPS siempre que el proveedor lo permita.
- Utilizar solo contenido y enlaces para los que se tenga autorización.

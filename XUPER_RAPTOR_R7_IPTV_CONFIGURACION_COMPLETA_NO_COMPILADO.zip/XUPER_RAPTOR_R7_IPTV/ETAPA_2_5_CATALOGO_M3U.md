# Etapa 2.5 — Catálogo M3U persistente (versión 0.3.0)

## Implementado en el código fuente

- Las entradas analizadas de una lista M3U se guardan en almacenamiento cifrado local junto con el registro de la fuente.
- Cada entrada conserva nombre, URL de reproducción, grupo, logo e identificador `tvg-id`.
- La pantalla Fuentes IPTV ofrece **VER CATÁLOGO** para fuentes M3U.
- El catálogo permite buscar por nombre/grupo y filtrar por algunos grupos detectados.
- **ACTUALIZAR LISTA** vuelve a descargar la URL y reemplaza el catálogo guardado si la operación termina correctamente.
- Al eliminar una fuente M3U también se elimina su catálogo almacenado.
- Se limita la lista visual a 1.500 filas para reducir el coste de renderizado; la búsqueda se realiza sobre el catálogo completo en memoria.

## Límites actuales

- Esta etapa se aplica a fuentes M3U/M3U8 por URL. Xtream Codes todavía solo se registra cifrado; no se consulta su API.
- Las filas del catálogo aún no reproducen vídeo. La integración de Media3/ExoPlayer es un paso posterior.
- No se importan archivos M3U locales.
- La actualización requiere conexión a internet y una URL accesible.
- La lista descargada se almacena en preferencias cifradas; listas enormes pueden consumir bastante almacenamiento/memoria. Para producción conviene migrar el catálogo a Room con paginación.
- La interfaz y el proyecto no se han compilado ni ejecutado en un dispositivo en este entorno. La compilación debe verificarse en Android Studio con JDK 17 y Android SDK 35.

## Pruebas manuales recomendadas

1. Importar una lista M3U autorizada y confirmar el número de entradas.
2. Abrir **VER CATÁLOGO**, buscar un nombre y filtrar por grupo.
3. Cerrar y volver a abrir la aplicación; comprobar que el catálogo sigue disponible.
4. Actualizar una lista modificada y comprobar que cambia el número de entradas.
5. Eliminar la fuente y comprobar que ya no aparece en el administrador.
6. Probar URL inaccesible, respuesta HTTP no exitosa, lista vacía y contenido no M3U.

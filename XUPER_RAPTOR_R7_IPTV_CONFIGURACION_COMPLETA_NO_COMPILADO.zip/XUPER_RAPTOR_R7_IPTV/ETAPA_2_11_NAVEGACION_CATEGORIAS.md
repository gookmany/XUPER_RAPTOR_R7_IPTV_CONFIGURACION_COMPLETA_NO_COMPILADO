# Etapa 2.11 — Navegación real de categorías (v0.9.0)

## Cambios
- Las tarjetas de inicio dejan de mostrar únicamente un mensaje genérico y abren el catálogo asociado a la primera fuente configurada.
- Para fuentes Xtream, LIVE, MOVIES y SERIES solicitan el catálogo correspondiente mediante las acciones compatibles del conector existente.
- Para listas M3U y catálogos ya guardados, las categorías LIVE/MOVIES/SERIES filtran por tipo de medio; KIDS y ANIME aplican filtros por nombre/grupo; FEATURED muestra hasta 100 entradas y EXPLORAR muestra el catálogo disponible.
- Se actualizó el número de versión visible a 0.9.0.

## Limitaciones conocidas
- El selector de fuente en Inicio utiliza la primera fuente registrada; todavía no existe un selector de fuentes por categoría.
- Los filtros KIDS/ANIME dependen de que el nombre o grupo contenga palabras reconocibles.
- FEATURED es una selección inicial de hasta 100 elementos, no una clasificación editorial del proveedor.
- La navegación de categorías no sustituye la compilación ni las pruebas en dispositivos reales.

## Validación
- Se modificó el código fuente y se verificará la estructura del ZIP.
- No se afirma que el proyecto compile ni que conecte con un proveedor real: la compilación Android y las pruebas de red siguen pendientes.
